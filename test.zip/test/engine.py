"""Sample 10x10 Anarchy Chess engine.

The engine stores one canonical board per match. show_state(match_id, user_id)
returns a copy oriented for the requesting player. Movement rules are random
for the prototype and should be replaced by the actual game rules later.
"""

# Piece Type Definitions (1 through 12)
KING = 1
QUEEN = 2
BISHOP = 3
ROOK = 4
HORSE = 5
CHECKER = 6
KNOOK = 7
PAWN = 8
STERILE_PAWN = 9
UNDERAGE_PAWN = 10
ANTIQUEEN = 11
TRAITORROOK = 12


import random
import string
from typing import Dict, List, Optional, Tuple

BOARD_SIZE = 10
EMPTY = 0
Position = Tuple[int, int]
Board = List[List[int]]

_games: Dict[str, dict] = {}

RANDOM_HISTORY_MESSAGES = [
    "Something is happening on the board.",
    "The pieces are preparing for another move.",
    "A new position has been reached.",
    "The game continues.",
    "The board state has changed.",
    "Another move has been completed.",
    "The players are deciding their next actions.",
    "A new situation has developed.",
]


def _random_id(length: int = 6) -> str:
    characters = string.ascii_uppercase + string.digits
    return "".join(random.choices(characters, k=length))


def _normalize_position(position) -> Optional[Position]:
    if not isinstance(position, (list, tuple)) or len(position) != 2:
        return None
    row, col = position
    if type(row) is not int or type(col) is not int:
        return None
    if not (0 <= row < BOARD_SIZE and 0 <= col < BOARD_SIZE):
        return None
    return row, col


def _create_random_board() -> Board:
    board = []

    for _row in range(BOARD_SIZE):
        board_row = []

        for _col in range(BOARD_SIZE):
            if random.random() < 0.40:
                piece = random.randint(1, 10)

                # Positive = white, negative = black.
                if random.choice([True, False]):
                    piece = -piece

                board_row.append(piece)
            else:
                board_row.append(EMPTY)

        board.append(board_row)

    if all(value == EMPTY for row in board for value in row):
        row = random.randrange(BOARD_SIZE)
        col = random.randrange(BOARD_SIZE)
        piece = random.randint(1, 10)

        if random.choice([True, False]):
            piece = -piece

        board[row][col] = piece

    return board


def create_game(match_id: str, player_a_id: str, player_b_id: str) -> Board:
    """Create a fresh game and record its two player IDs."""
    if not match_id or not player_a_id or not player_b_id:
        raise ValueError("match_id and both player IDs are required")
    if player_a_id == player_b_id:
        raise ValueError("A game requires two different players")

    board = _create_random_board()
    _games[match_id] = {
        "board": board,
        "player_a_id": player_a_id,
        "player_b_id": player_b_id,
        "movement_cache": {},
        "history": [
            f"Game initialized. Reference: {_random_id()}",
            random.choice(RANDOM_HISTORY_MESSAGES),
        ],
    }
    # Return the canonical orientation for initialization/debugging.
    return [row[:] for row in board]


def remove_game(match_id: str) -> None:
    """Delete all engine state for a closed match."""
    _games.pop(match_id, None)


def _get_game(match_id: str) -> dict:
    try:
        return _games[match_id]
    except KeyError as exc:
        raise KeyError(f"Unknown match ID: {match_id}") from exc


def is_flipped(match_id: str, user_id: str) -> bool:
    """Return whether this player should see the board rotated 180 degrees."""
    game = _get_game(match_id)
    if user_id == game["player_a_id"]:
        return False
    if user_id == game["player_b_id"]:
        return True
    raise ValueError("User is not a player in this game")


def show_state(match_id: str, user_id: str) -> Board:
    """Return the board oriented for this user; never expose internal rows."""
    game = _get_game(match_id)
    board = game["board"]
    flipped = is_flipped(match_id, user_id)
    if not flipped:
        return [row[:] for row in board]
    return [list(reversed(row)) for row in reversed(board)]


def show_movement(
    match_id: str,
    position,
    player_colour: str,
) -> Dict[str, Dict[str, List[List[int]]]]:
    """Return movement overlays for a piece owned by the requesting colour.

    Positive pieces belong to white; negative pieces belong to black.
    Positions use canonical [row, column] coordinates.
    """

    game = _get_game(match_id)

    empty_result = {
        "square": {},
        "dot": {},
    }

    if player_colour not in ("white", "black"):
        return empty_result

    source = _normalize_position(position)

    if source is None:
        return empty_result

    row, col = source
    board = game["board"]
    piece = board[row][col]

    # Empty squares have no movement options.
    if piece == EMPTY:
        return empty_result

    # Reject attempts to inspect movement options for the opponent's piece.
    if player_colour == "white" and piece < 0:
        return empty_result

    if player_colour == "black" and piece > 0:
        return empty_result

    cached_moves = game["movement_cache"].get(source)

    if cached_moves is None:
        candidates = [
            (target_row, target_col)
            for target_row in range(BOARD_SIZE)
            for target_col in range(BOARD_SIZE)
            if (target_row, target_col) != source
            and not (
                board[target_row][target_col] != EMPTY
                and (
                    (player_colour == "white"
                     and board[target_row][target_col] > 0)
                    or
                    (player_colour == "black"
                     and board[target_row][target_col] < 0)
                )
            )
        ]

        if not candidates:
            return empty_result

        cached_moves = random.sample(
            candidates,
            k=min(len(candidates), random.randint(2, 8)),
        )

        game["movement_cache"][source] = cached_moves

    result = {
        "square": {},
        "dot": {},
    }

    colour = "#e53935"

    for target_row, target_col in cached_moves:
        position_list = [target_row, target_col]

        if board[target_row][target_col] != EMPTY:
            overlay_type = "square"
        else:
            overlay_type = "dot"

        result[overlay_type].setdefault(colour, []).append(
            position_list
        )

    return result

def do_movement(
    match_id: str,
    source_position,
    target_position,
    player_colour: str,
) -> bool:
    """Execute a move if the source piece belongs to the requesting colour."""

    game = _get_game(match_id)

    if player_colour not in ("white", "black"):
        return False

    source = _normalize_position(source_position)
    target = _normalize_position(target_position)

    if source is None or target is None:
        return False

    source_row, source_col = source
    target_row, target_col = target

    board = game["board"]

    piece = board[source_row][source_col]

    if piece == EMPTY:
        return False

    # Verify ownership of the source piece.
    if player_colour == "white" and piece < 0:
        return False

    if player_colour == "black" and piece > 0:
        return False

    # Reject capturing a piece belonging to the moving player.
    target_piece = board[target_row][target_col]

    if player_colour == "white" and target_piece > 0:
        return False

    if player_colour == "black" and target_piece < 0:
        return False

    # Verify that the destination was generated by show_movement().
    possible_moves = game["movement_cache"].get(source, [])

    if target not in possible_moves:
        return False

    captured_piece = target_piece

    # Execute the move. The sign is preserved, so ownership is preserved.
    board[target_row][target_col] = piece
    board[source_row][source_col] = EMPTY

    # Invalidate cached movement options after the board changes.
    game["movement_cache"].clear()

    # Record the move using the absolute piece type.
    game["history"].append(
        f"{player_colour.capitalize()}'s piece {abs(piece)} moved from "
        f"({source_row}, {source_col}) to "
        f"({target_row}, {target_col})."
    )

    if captured_piece != EMPTY:
        captured_colour = (
            "black" if captured_piece < 0 else "white"
        )

        game["history"].append(
            f"{player_colour.capitalize()} captured "
            f"{captured_colour}'s piece {abs(captured_piece)}."
        )

    game["history"].append(
        random.choice(RANDOM_HISTORY_MESSAGES)
    )

    return True

def get_history(match_id: str) -> List[str]:
    """Return a copy of the sample text history."""
    return _get_game(match_id)["history"].copy()
