import asyncio
import random
import string
from contextlib import suppress
from typing import Dict, Optional
from pathlib import Path

import engine
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel


# ============================================================
# APPLICATION CONFIGURATION
# ============================================================

BASE_DIR = Path(__file__).resolve().parent
app = FastAPI()
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

LOBBY_TIMEOUT_SECONDS = 60
BOARD_SIZE = 10


# ============================================================
# DATA MODELS
# ============================================================

class Player:
    """A player session, independent of whether its browser is connected."""

    def __init__(self, session_id: str, username: str):
        self.session_id = session_id
        self.username = username
        self.websocket: Optional[WebSocket] = None
        self.active_match_id: Optional[str] = None
        self.expiry_task: Optional[asyncio.Task] = None
        self.connection_generation = 0


class Match:
    """One game between two players, with its own action lock."""

    def __init__(self, match_id: str, player_a: Player, player_b: Player):
        self.match_id = match_id
        self.p1 = player_a
        self.p2 = player_b
        self.active_player = random.choice([player_a, player_b])
        self.lock = asyncio.Lock()

        # Canonical [row, column] destination of the last successful move.
        self.last_turn_position = None


class SessionRequest(BaseModel):
    username: str


# All valid sessions, including players in matches.
players: Dict[str, Player] = {}
# Only players waiting for a match.
lobby_users: Dict[str, Player] = {}
# Active matches only.
active_matches: Dict[str, Match] = {}

# Serializes session/lobby/match transitions.
state_lock = asyncio.Lock()


# ============================================================
# GENERAL HELPERS
# ============================================================

def generate_random_string(length: int = 5) -> str:
    return "".join(random.choices(string.ascii_letters + string.digits, k=length))


def get_unique_match_id() -> str:
    match_id = generate_random_string(10)
    while match_id in active_matches:
        match_id = generate_random_string(10)
    return match_id


def player_belongs_to_match(match: Match, session_id: str) -> bool:
    return session_id in (match.p1.session_id, match.p2.session_id)


def get_match_opponent(match: Match, session_id: str) -> Optional[Player]:
    if match.p1.session_id == session_id:
        return match.p2
    if match.p2.session_id == session_id:
        return match.p1
    return None


def cancel_expiration(player: Player) -> None:
    task = player.expiry_task
    player.expiry_task = None
    if task is not None and not task.done():
        task.cancel()


def schedule_expiration(player: Player) -> None:
    cancel_expiration(player)
    player.expiry_task = asyncio.create_task(
        expire_lobby_session(player.session_id, player)
    )


async def safe_send(websocket: Optional[WebSocket], message: dict) -> bool:
    if websocket is None:
        return False
    try:
        await websocket.send_json(message)
        return True
    except Exception as exc:
        print(f"WebSocket send failed: {exc}")
        return False


async def send_to_player(player: Player, message: dict) -> bool:
    return await safe_send(player.websocket, message)


def normalize_position(position):
    """Validate a zero-based [row, column] position."""
    if not isinstance(position, (list, tuple)) or len(position) != 2:
        return None
    row, col = position
    if type(row) is not int or type(col) is not int:
        return None
    if not (0 <= row < BOARD_SIZE and 0 <= col < BOARD_SIZE):
        return None
    return [row, col]


def transform_position(position, flipped: bool):
    """Convert between a player's displayed coordinates and canonical ones.

    A 180-degree rotation is its own inverse, so this helper works in both
    directions. Invalid positions return None.
    """
    normalized = normalize_position(position)
    if normalized is None:
        return None
    row, col = normalized
    if flipped:
        return [BOARD_SIZE - 1 - row, BOARD_SIZE - 1 - col]
    return [row, col]


# ============================================================
# LOBBY BROADCASTING
# ============================================================

def build_lobby_snapshot() -> list:
    return [
        {"username": player.username, "sid": player.session_id}
        for player in lobby_users.values()
    ]


async def broadcast_lobby_update() -> None:
    """Broadcast one complete, identical lobby snapshot to all lobby sockets."""
    message = {"type": "LOBBY_UPDATE", "users": build_lobby_snapshot()}
    connected_players = [p for p in list(lobby_users.values()) if p.websocket]
    await asyncio.gather(
        *(send_to_player(player, message) for player in connected_players),
        return_exceptions=True,
    )


# ============================================================
# GAME STATE / ORIENTATION
# ============================================================

def build_game_state_payload(match: Match, viewer_sid: str) -> dict:
    """Build a viewer-specific board while preserving one canonical engine state."""
    flipped = viewer_sid == match.p2.session_id

    last_turn_position = None

    if match.last_turn_position is not None:
        last_turn_position = transform_position(
            match.last_turn_position,
            flipped,
        )

    return {
        "type": "GAME_STATE",
        "match_id": match.match_id,
        "board": engine.show_state(match.match_id, viewer_sid),
        "history": engine.get_history(match.match_id),
        "player_a_sid": match.p1.session_id,
        "player_a_username": match.p1.username,
        "player_b_sid": match.p2.session_id,
        "player_b_username": match.p2.username,
        "active_player_sid": match.active_player.session_id,
        "can_move": match.active_player.session_id == viewer_sid,
        "last_turn_position": last_turn_position,
    }


async def send_game_start(match: Match) -> None:
    """Redirect both players to the new/current match URL."""
    for player in (match.p1, match.p2):
        await send_to_player(
            player,
            {
                "type": "GAME_START",
                "match_id": match.match_id,
                "redirect_url": f"/game/{match.match_id}?sid={player.session_id}",
            },
        )


# ============================================================
# LOBBY SESSION EXPIRATION
# ============================================================

async def expire_lobby_session(session_id: str, expected_player: Player) -> None:
    try:
        await asyncio.sleep(LOBBY_TIMEOUT_SECONDS)
        async with state_lock:
            if players.get(session_id) is not expected_player:
                return
            if expected_player.active_match_id is not None:
                return
            if expected_player.websocket is not None:
                return
            if lobby_users.get(session_id) is not expected_player:
                return

            lobby_users.pop(session_id, None)
            players.pop(session_id, None)
            expected_player.expiry_task = None
            print(f"Lobby session expired: {expected_player.username} ({session_id})")
            await broadcast_lobby_update()
    except asyncio.CancelledError:
        pass


# ============================================================
# HTTP ROUTES
# ============================================================

@app.get("/")
async def index(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={"sid": "", "match_id": "", "screen": "landing"},
    )


@app.post("/api/create-session")
async def create_session(request: SessionRequest):
    username = request.username.strip()
    if not username:
        return JSONResponse({"error": "Username is required."}, status_code=400)
    if len(username) > 30:
        return JSONResponse(
            {"error": "Username must be 30 characters or fewer."},
            status_code=400,
        )

    async with state_lock:
        sid = generate_random_string()
        while sid in players:
            sid = generate_random_string()
        player = Player(sid, username)
        players[sid] = player
        lobby_users[sid] = player
        print(f"Session created: {username} ({sid})")
        await broadcast_lobby_update()

    return JSONResponse({"sid": sid})


@app.get("/lobby")
async def lobby_page(request: Request, sid: str):
    async with state_lock:
        player = players.get(sid)
        if player is None:
            return HTMLResponse(
                content="<h1>Invalid Session</h1><p>This session has expired. Please join again.</p>",
                status_code=404,
            )
        if player.active_match_id:
            match = active_matches.get(player.active_match_id)
            if match is not None:
                return RedirectResponse(
                    url=f"/game/{match.match_id}?sid={sid}",
                    status_code=303,
                )
        if lobby_users.get(sid) is not player:
            return HTMLResponse("<h1>Invalid Session</h1>", status_code=404)

    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={"sid": sid, "match_id": "", "screen": "lobby"},
    )


@app.get("/game/{match_id}")
async def game_page(request: Request, match_id: str, sid: str):
    async with state_lock:
        match = active_matches.get(match_id)
        if match is None:
            # If the player has already been moved to another match, take them there.
            player = players.get(sid)
            if player and player.active_match_id:
                current = active_matches.get(player.active_match_id)
                if current and player_belongs_to_match(current, sid):
                    return RedirectResponse(
                        url=f"/game/{current.match_id}?sid={sid}",
                        status_code=303,
                    )
            if player and sid in lobby_users:
                return RedirectResponse(url=f"/lobby?sid={sid}", status_code=303)
            return HTMLResponse("<h1>Match Not Found</h1>", status_code=404)
        if not player_belongs_to_match(match, sid):
            return HTMLResponse("<h1>Access Denied</h1>", status_code=403)

    return templates.TemplateResponse(
        request=request,
        name="game.html",
        context={"sid": sid, "match_id": match_id},
    )


# ============================================================
# MATCH CREATION / REMATCH / CLOSE
# ============================================================

async def start_match(challenger_sid: str, target_sid: str) -> Optional[Match]:
    async with state_lock:
        challenger = lobby_users.get(challenger_sid)
        target = lobby_users.get(target_sid)

        if challenger is None or target is None or challenger_sid == target_sid:
            return None
        if challenger.websocket is None or target.websocket is None:
            return None
        if challenger.active_match_id is not None or target.active_match_id is not None:
            return None

        cancel_expiration(challenger)
        cancel_expiration(target)

        match_id = get_unique_match_id()
        match = Match(match_id, challenger, target)
        engine.create_game(match_id, challenger.session_id, target.session_id)

        active_matches[match_id] = match
        challenger.active_match_id = match_id
        target.active_match_id = match_id
        lobby_users.pop(challenger_sid, None)
        lobby_users.pop(target_sid, None)

        print(f"Match started: {match_id} ({challenger.username} vs {target.username})")
        await broadcast_lobby_update()

    await send_game_start(match)
    return match


async def create_new_match_from_existing(
    old_match_id: str,
    requester_sid: str,
) -> tuple[Optional[Match], bool]:
    """Replace a match with a fresh match between the same two players.

    Idempotent for a stale/double click: if old_match_id has already been
    replaced and the requester is already in a newer match, return that match
    rather than creating another one.
    """
    async with state_lock:
        old_match = active_matches.get(old_match_id)
        requester = players.get(requester_sid)

        if requester is None:
            return None, False

        if old_match is None:
            current = active_matches.get(requester.active_match_id or "")
            if current is not None and player_belongs_to_match(current, requester_sid):
                return current, False
            return None, False

        if not player_belongs_to_match(old_match, requester_sid):
            return None, False
        if requester.active_match_id != old_match_id:
            current = active_matches.get(requester.active_match_id or "")
            if current is not None and player_belongs_to_match(current, requester_sid):
                return current, False
            return None, False

        async with old_match.lock:
            # Re-check after acquiring the match lock.
            if active_matches.get(old_match_id) is not old_match:
                current = active_matches.get(requester.active_match_id or "")
                if current is not None and player_belongs_to_match(current, requester_sid):
                    return current, False
                return None, False

            player_a, player_b = old_match.p1, old_match.p2
            new_match_id = get_unique_match_id()
            new_match = Match(new_match_id, player_a, player_b)
            engine.create_game(new_match_id, player_a.session_id, player_b.session_id)

            active_matches.pop(old_match_id, None)
            active_matches[new_match_id] = new_match
            player_a.active_match_id = new_match_id
            player_b.active_match_id = new_match_id
            engine.remove_game(old_match_id)

            print(f"Match {old_match_id} replaced with fresh match {new_match_id}")

    return new_match, True


async def close_match_to_lobby(match_id: str, requester_sid: str) -> Optional[Match]:
    """Close the current match and return both participants to the lobby."""
    async with state_lock:
        match = active_matches.get(match_id)
        requester = players.get(requester_sid)

        # A duplicate/stale click must not close a newer match.
        if match is None:
            if requester and requester.active_match_id:
                current = active_matches.get(requester.active_match_id)
                if current is not None and player_belongs_to_match(current, requester_sid):
                    return None
            if requester and requester_sid in lobby_users:
                return None
            return None

        if not player_belongs_to_match(match, requester_sid):
            return None
        if requester is None or requester.active_match_id != match_id:
            return None

        async with match.lock:
            if active_matches.get(match_id) is not match:
                return None

            active_matches.pop(match_id, None)
            engine.remove_game(match_id)

            for player in (match.p1, match.p2):
                player.active_match_id = None
                if players.get(player.session_id) is player:
                    lobby_users[player.session_id] = player
                    if player.websocket is None:
                        schedule_expiration(player)

            await broadcast_lobby_update()

    for player in (match.p1, match.p2):
        await send_to_player(
            player,
            {"type": "GAME_OVER", "reason": "The match was closed."},
        )
        await send_to_player(
            player,
            {
                "type": "RETURN_TO_LOBBY",
                "redirect_url": f"/lobby?sid={player.session_id}",
            },
        )

    print(f"Match closed and players returned to lobby: {match_id}")
    return match


async def send_player_to_current_location(player: Player) -> None:
    """Recover gracefully from a stale game action after a navigation race."""
    if player.active_match_id:
        match = active_matches.get(player.active_match_id)
        if match and player_belongs_to_match(match, player.session_id):
            await send_to_player(
                player,
                {
                    "type": "GAME_START",
                    "match_id": match.match_id,
                    "redirect_url": f"/game/{match.match_id}?sid={player.session_id}",
                },
            )
            return
    if player.session_id in lobby_users:
        await send_to_player(
            player,
            {
                "type": "RETURN_TO_LOBBY",
                "redirect_url": f"/lobby?sid={player.session_id}",
            },
        )


# ============================================================
# WEBSOCKET HANDLER
# ============================================================

@app.websocket("/ws/{session_id}")
async def websocket_endpoint(websocket: WebSocket, session_id: str):
    await websocket.accept()

    player: Optional[Player] = None
    generation: Optional[int] = None
    old_websocket: Optional[WebSocket] = None

    async with state_lock:
        player = players.get(session_id)
        if player is None:
            await safe_send(websocket, {"type": "INVALID_SESSION"})
            await websocket.close(code=1008)
            return

        old_websocket = player.websocket
        player.connection_generation += 1
        generation = player.connection_generation
        player.websocket = websocket
        cancel_expiration(player)
        print(f"Client connected/re-connected: {player.username} ({session_id})")

    if old_websocket is not None and old_websocket is not websocket:
        with suppress(Exception):
            await old_websocket.close(code=1000, reason="Reconnected from another connection")

    try:
        await safe_send(
            websocket,
            {"type": "LOBBY_READY", "sid": session_id, "username": player.username},
        )

        if player.active_match_id:
            match = active_matches.get(player.active_match_id)
            if match is not None and player_belongs_to_match(match, session_id):
                async with match.lock:
                    await safe_send(websocket, build_game_state_payload(match, session_id))
        elif session_id in lobby_users:
            await broadcast_lobby_update()

        while True:
            data = await websocket.receive_json()
            if player.connection_generation != generation:
                break
            if not isinstance(data, dict):
                continue

            message_type = data.get("type")

            # ------------------------------------------------
            # Lobby membership confirmation
            # ------------------------------------------------
            if message_type == "JOIN_LOBBY":
                async with state_lock:
                    if players.get(session_id) is not player:
                        await safe_send(websocket, {"type": "INVALID_SESSION"})
                        continue
                    if player.active_match_id is None:
                        cancel_expiration(player)
                        lobby_users[session_id] = player
                        await broadcast_lobby_update()

            # ------------------------------------------------
            # Request game state
            # ------------------------------------------------
            elif message_type in ("JOIN_GAME", "GET_GAME_STATE"):
                requested_match_id = data.get("match_id") or player.active_match_id
                match = active_matches.get(requested_match_id or "")
                if (
                    match is None
                    or not player_belongs_to_match(match, session_id)
                    or player.active_match_id != requested_match_id
                ):
                    await send_player_to_current_location(player)
                    continue
                async with match.lock:
                    await safe_send(websocket, build_game_state_payload(match, session_id))

            # ------------------------------------------------
            # Lobby challenge
            # ------------------------------------------------
            elif message_type == "CHALLENGE":
                target_sid = data.get("target_sid")
                if not isinstance(target_sid, str) or target_sid == session_id:
                    continue
                async with state_lock:
                    challenger = lobby_users.get(session_id)
                    target = lobby_users.get(target_sid)
                    if (
                        challenger is None or target is None
                        or challenger.websocket is None or target.websocket is None
                    ):
                        continue
                    await send_to_player(
                        target,
                        {
                            "type": "MATCH_REQUEST",
                            "from_sid": session_id,
                            "from_username": player.username,
                        },
                    )

            # ------------------------------------------------
            # Accept challenge
            # ------------------------------------------------
            elif message_type == "ACCEPT_CHALLENGE":
                challenger_sid = data.get("challenger_sid")
                if not isinstance(challenger_sid, str):
                    continue
                match = await start_match(challenger_sid, session_id)
                if match is None:
                    await safe_send(
                        websocket,
                        {
                            "type": "MOVE_REJECTED",
                            "reason": "Unable to start the match. A player may have disconnected or entered another match.",
                        },
                    )

            # ------------------------------------------------
            # Get movement options (display coordinates in, display coordinates out)
            # ------------------------------------------------
            elif message_type == "SHOW_MOVEMENT":
                requested_match_id = data.get("match_id") or player.active_match_id
                match = active_matches.get(requested_match_id or "")
                if (
                    match is None
                    or not player_belongs_to_match(match, session_id)
                    or player.active_match_id != requested_match_id
                ):
                    await send_player_to_current_location(player)
                    continue

                display_position = normalize_position(data.get("position"))
                flipped = session_id == match.p2.session_id
                engine_position = transform_position(display_position, flipped) if display_position is not None else None

                async with match.lock:
                    if active_matches.get(requested_match_id) is not match:
                        continue
                    if engine_position is None:
                        moves_for_view = {
                            "square": {},
                            "dot": {},
                        }
                    else:
                        player_colour = (
                            "black"
                            if session_id == match.p2.session_id
                            else "white"
                        )

                        engine_moves = engine.show_movement(
                            requested_match_id,
                            engine_position,
                            player_colour,
                        )

                        moves_for_view = {
                            "square": {},
                            "dot": {},
                        }

                        for overlay_type in ("square", "dot"):
                            for colour, positions in engine_moves.get(
                                overlay_type,
                                {},
                            ).items():
                                moves_for_view[overlay_type][colour] = [
                                    transform_position(position, flipped)
                                    for position in positions
                                ]
                            

                    await safe_send(
                        websocket,
                        {
                            "type": "MOVEMENT_OPTIONS",
                            "match_id": requested_match_id,
                            "position": display_position,
                            "moves": moves_for_view,
                        },
                    )

            # ------------------------------------------------
            # Execute movement
            # ------------------------------------------------
            elif message_type == "DO_MOVEMENT":
                requested_match_id = data.get("match_id") or player.active_match_id
                match = active_matches.get(requested_match_id or "")
                if (
                    match is None
                    or not player_belongs_to_match(match, session_id)
                    or player.active_match_id != requested_match_id
                ):
                    await send_player_to_current_location(player)
                    continue

                flipped = session_id == match.p2.session_id
                display_source = normalize_position(data.get("from_pos"))
                display_target = normalize_position(data.get("to_pos"))
                source = transform_position(display_source, flipped) if display_source is not None else None
                target = transform_position(display_target, flipped) if display_target is not None else None
                rejection_reason = None
                updates = []

                async with match.lock:
                    # The old game may have been closed while this request waited.
                    if active_matches.get(requested_match_id) is not match:
                        rejection_reason = "This match is already closed."
                    elif match.active_player.session_id != session_id:
                        rejection_reason = "It is not your turn."
                    elif source is None or target is None:
                        rejection_reason = "Invalid source or destination position."
                    else:
                        player_colour = (
                            "black"
                            if session_id == match.p2.session_id
                            else "white"
                        )

                        engine_moves = engine.show_movement(
                            requested_match_id,
                            source,
                            player_colour,
                        )

                        # Extract all destination positions, regardless of overlay type or colour.
                        possible_positions = [
                            position
                            for overlay_type in ("square", "dot")
                            for positions in engine_moves.get(overlay_type, {}).values()
                            for position in positions
                        ]

                        if target not in possible_positions:
                            rejection_reason = "Invalid movement destination."
                        else:
                            player_colour = (
                                "black"
                                if session_id == match.p2.session_id
                                else "white"
                            )

                            move_succeeded = engine.do_movement(
                                requested_match_id,
                                source,
                                target,
                                player_colour,
                            )

                            # Update the last-move highlight and switch turns only on success.
                            if move_succeeded:
                                match.last_turn_position = target[:]

                                opponent = get_match_opponent(match, session_id)

                                if opponent is not None:
                                    match.active_player = opponent

                            # Send the current state to both players even if the engine returns False.
                            updates = [
                                (
                                    recipient,
                                    build_game_state_payload(
                                        match,
                                        recipient.session_id,
                                    ),
                                )
                                for recipient in (match.p1, match.p2)
                            ]

                if rejection_reason:
                    await safe_send(
                        websocket,
                        {"type": "MOVE_REJECTED", "reason": rejection_reason},
                    )
                else:
                    for recipient, payload in updates:
                        await send_to_player(recipient, payload)

            # ------------------------------------------------
            # New Game: replace this match with a fresh match for both players.
            # ------------------------------------------------
            elif message_type == "NEW_GAME":
                requested_match_id = data.get("match_id") or player.active_match_id
                if not isinstance(requested_match_id, str):
                    await send_player_to_current_location(player)
                    continue

                new_match, created = await create_new_match_from_existing(
                    requested_match_id,
                    session_id,
                )
                if new_match is None:
                    await send_player_to_current_location(player)
                elif created:
                    # Both players are redirected into the newly created match.
                    await send_game_start(new_match)
                else:
                    # Duplicate/stale click: rejoin the current match without
                    # creating another one.
                    await send_to_player(
                        player,
                        {
                            "type": "GAME_START",
                            "match_id": new_match.match_id,
                            "redirect_url": f"/game/{new_match.match_id}?sid={session_id}",
                        },
                    )

            # ------------------------------------------------
            # Back to Lobby: close the match for both players.
            # ------------------------------------------------
            elif message_type in ("BACK_TO_LOBBY", "LEAVE_GAME"):
                requested_match_id = data.get("match_id") or player.active_match_id
                if not isinstance(requested_match_id, str):
                    await send_player_to_current_location(player)
                    continue

                closed = await close_match_to_lobby(
                    requested_match_id,
                    session_id,
                )
                if closed is None:
                    await send_player_to_current_location(player)

    except WebSocketDisconnect:
        print(f"Client disconnected: {session_id}")
    except Exception as exc:
        print(f"WebSocket error for {session_id}: {exc}")
    finally:
        should_broadcast = False
        async with state_lock:
            current_player = players.get(session_id)
            if (
                current_player is player
                and player.connection_generation == generation
                and player.websocket is websocket
            ):
                player.websocket = None
                if (
                    player.active_match_id is None
                    and lobby_users.get(session_id) is player
                ):
                    schedule_expiration(player)
                    should_broadcast = True
        if should_broadcast:
            await broadcast_lobby_update()
